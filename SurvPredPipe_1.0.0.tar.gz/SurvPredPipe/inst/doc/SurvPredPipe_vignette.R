## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
#Load SurvPredPipe packages
library(SurvPredPipe)
#Load other required packages
library(caret)
library(preprocessCore)
library(ggfortify)
library(survival)
library(survminer)
library(dplyr)
library(ggplot2)
library(ggfortify)
library(MASS)
library(MTLR)
library(dplyr)
library(SurvMetrics)
library(pec)
library(glmnet)
library(reshape2)
library(rms)
library(Matrix)
library(Hmisc)
library(survivalROC)
library(ROCR)

## -----------------------------------------------------------------------------
#set path of the working directory where input data available
#setwd()

#set seed
set.seed(7)

## -----------------------------------------------------------------------------
data_process_f(data="../inst/extdata/Example_TCGA_LGG_FPKM_data.txt",col_num=20, surv_time="OS.time" , output="New_data.txt")

## -----------------------------------------------------------------------------
tr_test_f(data="../inst/extdata/New_data.txt",fraction=0.9,
	  train_data="train_FPKM.txt", 
	  test_data="test_FPKM.txt")

## -----------------------------------------------------------------------------
# Step 3 - Data Normalization


## -----------------------------------------------------------------------------
# Normalize the training and test datasets
train_test_normalization_f(train_data = "../inst/extdata/train_FPKM.txt",
                            test_data = "../inst/extdata/test_FPKM.txt",
                            col_num = 21,
                            train_clin_data = "Train_Clin.txt",
                            test_clin_data = "Test_Clin.txt",
                            train_Normalized_data_clin_data = "Train_Norm_data.txt",
                            test_Normalized_data_clin_data = "Test_Norm_data.txt")


## -----------------------------------------------------------------------------
Lasso_PI_scores_f(train_data="../inst/extdata/Train_Norm_data.txt",test_data="../inst/extdata/Test_Norm_data.txt", nfolds=5, col_num=21, surv_time="OS_month" , surv_event="OS" , train_PI_data="Train_PI_data.txt", test_PI_data="Test_PI_data.txt" )

## -----------------------------------------------------------------------------
Univariate_sig_features_f(train_data="../inst/extdata/Train_Norm_data.txt", test_data="../inst/extdata/Test_Norm_data.txt", col_num=21, surv_time="OS_month" , surv_event="OS" ,output_univariate_train="Train_Uni_sig_data.txt", output_univariate_test="Test_Uni_sig_data.txt")

## -----------------------------------------------------------------------------
MTLR_pred_model_f(train_clin_data = "../inst/extdata/Train_Clin.txt", test_clin_data = "../inst/extdata/Test_Clin.txt", Model_type = 1, train_features_data = "../inst/extdata/Train_Clin.txt", test_features_data = "../inst/extdata/Test_Clin.txt" , Clin_Feature_List="../inst/extdata/Key_Clin_feature_list.txt", surv_time="OS_month", surv_event="OS")

## -----------------------------------------------------------------------------
MTLR_pred_model_f(train_clin_data = "../inst/extdata/Train_Clin.txt", test_clin_data = "../inst/extdata/Test_Clin.txt", Model_type = 2, train_features_data = "../inst/extdata/Train_PI_data.txt", test_features_data = "../inst/extdata/Test_PI_data.txt" , Clin_Feature_List="../inst/extdata/Key_PI_list.txt", surv_time="OS_month", surv_event="OS")

## -----------------------------------------------------------------------------
MTLR_pred_model_f(train_clin_data = "../inst/extdata/Train_Clin.txt", test_clin_data = "../inst/extdata/Test_Clin.txt", Model_type = 3, train_features_data = "../inst/extdata/Train_PI_data.txt", test_features_data = "../inst/extdata/Test_PI_data.txt" , Clin_Feature_List="../inst/extdata/Key_Clin_features_with_PI_list.txt", surv_time="OS_month",  surv_event="OS")

## -----------------------------------------------------------------------------
MTLR_pred_model_f(train_clin_data = "../inst/extdata/Train_Clin.txt", test_clin_data = "../inst/extdata/Test_Clin.txt", Model_type = 4, train_features_data = "../inst/extdata/Train_Uni_sig_data.txt", test_features_data = "../inst/extdata/Test_Uni_sig_data.txt" , Clin_Feature_List="../inst/extdata/Key_univariate_features_list.txt",  surv_time="OS_month", surv_event="OS")

## -----------------------------------------------------------------------------
MTLR_pred_model_f(train_clin_data = "../inst/extdata/Train_Clin.txt", test_clin_data = "../inst/extdata/Test_Clin.txt", Model_type = 5, train_features_data = "../inst/extdata/Train_Uni_sig_data.txt", test_features_data = "../inst/extdata/Test_Uni_sig_data.txt" , Clin_Feature_List="../inst/extdata/Key_univariate_features_with_Clin_list.txt", surv_time="OS_month", surv_event="OS")


## -----------------------------------------------------------------------------
#Create Survival curves/plots for individual patients
surv_curve_plots_f(Surv_curve_data="../inst/extdata/survCurves_data.txt", selected_sample="TCGA-TQ-A8XE-01")

## -----------------------------------------------------------------------------
mean_median_surv_barplot_f(surv_mean_med_data="../inst/extdata/mean_median_survival_time_data.txt", selected_sample="TCGA-TQ-A8XE-01")

## -----------------------------------------------------------------------------
Nomogram_generate_f(data="../inst/extdata/Train_Data_Nomogram_input.txt",  Feature_List="../inst/extdata/feature_list_for_Nomogram.txt", surv_time="OS_month", surv_event="OS")


